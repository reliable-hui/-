#include "armv4l2opencv.h"

#include <QApplication>
#include <QTextCodec>
#include <QByteArray>

int main(int argc, char *argv[])
{
    qputenv("QT_IM_MODULE", QByteArray("qtvirtualkeyboard"));
    QApplication a(argc, argv);
    ArmV4l2Opencv w;
    w.show();
    return a.exec();
}
